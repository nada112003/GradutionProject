﻿namespace GradutionP.DTO
{
    public class DoctorSearchDto
    {
     
            public string Query { get; set; }
           
        }

    
}
