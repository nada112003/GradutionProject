﻿namespace GradutionP.DTO
{
    public class FavoriteDto
    {
        public int PatientId { get; set; }
        public int DoctorId { get; set; }

    }

}
