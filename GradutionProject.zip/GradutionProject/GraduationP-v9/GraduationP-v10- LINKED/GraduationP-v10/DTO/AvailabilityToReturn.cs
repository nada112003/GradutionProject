﻿namespace GraduationP_v10.DTO
{
    public class AvailabilityToReturn
    {
        public int DoctorId { get; set; }
        public string Day { get; set; }
        public double StartTimeInHours { get; set; }
        public double EndTimeInHours { get; set; }
    }
}
